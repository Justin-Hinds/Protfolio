Developer: Justin Hinds

Sticks App Version 0.8.1

You can register with a valid email address and password at least 6 characters long. I am using cocoa pods so .xcworkspace is the file to open.