Developer: Justin Hinds

Sticks App Version 0.0.5

You can register with a valid email address and password atlas 6 characters longI am using cocoa pods so .xcworkspace is the file to open.