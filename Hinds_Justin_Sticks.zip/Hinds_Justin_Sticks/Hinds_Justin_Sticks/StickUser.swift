//
//  StickUser.swift
//  Hinds_Justin_Sticks
//
//  Created by Justin Hinds on 8/12/16.
//  Copyright © 2016 Justin Hinds. All rights reserved.
//

import UIKit

class StickUser: NSObject {
    var id: String?
    var name: String?
    var email: String?
    var profileImagURL: String?
}
