Developer: Justin Hinds

Sticks App Version 0.9.6

Git - https://github.com/Justin-Hinds/Protfolio/tree/master/Hinds_Justin_Sticks

You can register with a valid email address and password at least 6 characters long. I am using cocoa pods so .xcworkspace is the file to open.
swipe right for the posting view
swipe left for settings view where you can change the news feed preference.
post interactions do not currently work.