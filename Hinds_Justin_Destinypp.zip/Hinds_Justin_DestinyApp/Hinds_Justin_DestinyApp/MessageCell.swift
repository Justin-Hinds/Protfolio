//
//  MessageCell.swift
//  Hinds_Justin_DestinyApp
//
//  Created by Justin Hinds on 7/23/16.
//  Copyright © 2016 Justin Hinds. All rights reserved.
//

import Foundation
import UIKit

class MessageCell: UICollectionViewCell {
    @IBOutlet weak var message: UILabel!
    
}