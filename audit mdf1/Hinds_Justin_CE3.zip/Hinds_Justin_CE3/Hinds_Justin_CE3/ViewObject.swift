//
//  ViewObject.swift
//  Hinds_Justin_CE3
//
//  Created by Justin Hinds on 10/11/16.
//  Copyright © 2016 Justin Hinds. All rights reserved.
//

import UIKit

class ViewObject {
    var title : String?
    var img : UIImage?
    init(name : String, image : UIImage) {
        title = name
        img = image
    }
}
