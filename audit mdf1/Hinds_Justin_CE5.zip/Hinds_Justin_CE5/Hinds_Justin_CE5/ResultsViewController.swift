//
//  ViewController.swift
//  Hinds_Justin_CE5
//
//  Created by Justin Hinds on 10/11/16.
//  Copyright © 2016 Justin Hinds. All rights reserved.
//

import UIKit

class ResultsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

