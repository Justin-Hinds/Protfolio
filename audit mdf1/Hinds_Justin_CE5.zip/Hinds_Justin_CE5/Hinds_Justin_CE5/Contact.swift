//
//  Contact.swift
//  Hinds_Justin_CE5
//
//  Created by Justin Hinds on 10/11/16.
//  Copyright © 2016 Justin Hinds. All rights reserved.
//

import Foundation

class Contact {
    var name : String?
    var relationship : String?
    
    init(name: String, relationship : String) {
        self.name = name
        self.relationship = relationship
        
    }
    
}
