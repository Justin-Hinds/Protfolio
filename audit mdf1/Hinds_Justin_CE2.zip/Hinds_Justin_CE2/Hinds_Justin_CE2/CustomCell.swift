//
//  CustomCell.swift
//  Hinds_Justin_CE2
//
//  Created by Justin Hinds on 10/2/16.
//  Copyright © 2016 Justin Hinds. All rights reserved.
//

import UIKit

class CustomCell: UITableViewCell {
    
    @IBOutlet weak var item: UILabel!
    
    @IBOutlet weak var price: UILabel!
    
    @IBOutlet weak var itemImage: UIImageView!
}
