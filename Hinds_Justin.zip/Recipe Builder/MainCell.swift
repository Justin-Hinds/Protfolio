//
//  Custom Cell.swift
//  Recipe Builder
//
//  Created by Justin Hinds on 5/13/16.
//  Copyright © 2016 Justin Hinds. All rights reserved.
//

import Foundation

class MainCell: UITableViewCell {
    
}