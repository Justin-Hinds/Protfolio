Developer: Justin Hinds
Recipe Builder Version 0.2.5
Git - https://github.com/Justin-Hinds/Protfolio/commits/master

Currently the only thing working is the Facebook sign in. Everything else is a skeleton in place for development next week. Cocoa pods was used so yo may need to use the .xcworkspace file in order to get it to build properly.