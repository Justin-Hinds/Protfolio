Developer: Justin Hinds
Destiny App Version 0.0.5
Git - https://github.com/Justin-Hinds/Protfolio/tree/master/Hinds_Justin_DestinyApp

You can register with a valid email address and password atlas 6 characters long, the gamertag is currently irrelevant I have it set to pull my data currently for testing.
I am using cocoa pods so .xcworkspace is the file to open.