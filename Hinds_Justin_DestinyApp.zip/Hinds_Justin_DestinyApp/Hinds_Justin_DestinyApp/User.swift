//
//  Users.swift
//  Hinds_Justin_DestinyApp
//
//  Created by Justin Hinds on 7/22/16.
//  Copyright © 2016 Justin Hinds. All rights reserved.
//

import Foundation
import UIKit

class User: NSObject {
    var id : String?
    var name : String?
    var email : String?
}