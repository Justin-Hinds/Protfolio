//
//  PaintingCollectionViewCell.swift
//  
//
//  Created by Justin Hinds on 11/5/16.
//
//

import UIKit

class PaintingCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var paintingImage: UIImageView!
    
    
}
