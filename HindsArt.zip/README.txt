Developer: Justin Hinds

HindsArt Version 0.1.5

Git - https://github.com/Justin-Hinds/Protfolio/tree/master/HindsArt

You can register artists, tap the profile icon to upload personal image. on the upload page tap the blank space to pull up a image picker in order to upload images of paintings. artist list currently not up.