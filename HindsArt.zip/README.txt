Developer: Justin Hinds

HindsArt Version 1.0.0

Git - https://github.com/Justin-Hinds/Protfolio/tree/master/HindsArt

You can register artists, tap the profile icon to upload personal image. on the upload page tap the blank space to pull up a image picker in order to upload images of paintings. artist list currently not up. tap the picture frame to upload image of the painting. to test card based purchases the card number is 4111 1111 1111 1111 and any expiration date that would be valid.