//
//  ViewController.swift
//  HindsArt
//
//  Created by Justin Hinds on 10/28/16.
//  Copyright © 2016 Justin Hinds. All rights reserved.
//

import UIKit

class CustomTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

